package com.baxtiyorov.security

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private var lastApkUri: Uri? = null

    private val pickApkLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { scanApkFile(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.appRecyclerView)
        progressBar = findViewById(R.id.progressBar)
        recyclerView.layoutManager = LinearLayoutManager(this)

        setupLangSpinner()
        applyLanguageToStaticViews()

        findViewById<View>(R.id.scanApkButton).setOnClickListener {
            pickApkLauncher.launch(arrayOf("application/vnd.android.package-archive"))
        }

        loadInstalledApps()
    }

    private fun setupLangSpinner() {
        val spinner = findViewById<Spinner>(R.id.langSpinner)
        val labels = listOf("Qaraqalpaqsha", "O'zbekcha", "Русский")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        spinner.setSelection(0)
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                Lang.current = when (position) {
                    1 -> AppLang.UZ
                    2 -> AppLang.RU
                    else -> AppLang.KAA
                }
                applyLanguageToStaticViews()
                loadInstalledApps()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
    }

    private fun applyLanguageToStaticViews() {
        findViewById<android.widget.TextView>(R.id.titleText).text = Lang.t("app_name")
        findViewById<android.widget.Button>(R.id.scanApkButton).text = Lang.t("scan_apk_file")
        findViewById<android.widget.TextView>(R.id.sectionLabel).text = Lang.t("installed_apps")
    }

    private fun loadInstalledApps() {
        progressBar.visibility = View.VISIBLE
        recyclerView.visibility = View.GONE

        CoroutineScope(Dispatchers.Main).launch {
            val results = withContext(Dispatchers.IO) {
                val apps = ApkUtils.listInstalledApps(this@MainActivity)
                apps.map { entry ->
                    val unknownSource = entry.installerPackage == null
                    entry to RiskAnalyzer.analyze(entry.permissions, unknownSource, entry.isSystemApp)
                }.sortedByDescending { it.second.score }
            }

            recyclerView.adapter = AppListAdapter(results) { entry, risk ->
                openDetail(entry, risk, hash = null)
            }
            progressBar.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
        }
    }

    private fun scanApkFile(uri: Uri) {
        lastApkUri = uri
        progressBar.visibility = View.VISIBLE

        CoroutineScope(Dispatchers.Main).launch {
            val result = withContext(Dispatchers.IO) {
                val entry = ApkUtils.analyzeApkFile(this@MainActivity, uri)
                val hash = ApkUtils.sha256OfUri(this@MainActivity, uri)
                entry?.let {
                    val risk = RiskAnalyzer.analyze(it.permissions, isFromUnknownSource = true, isSystemApp = false)
                    Triple(it, risk, hash)
                }
            }
            progressBar.visibility = View.GONE

            if (result == null) {
                Toast.makeText(this@MainActivity, Lang.t("analysis_failed"), Toast.LENGTH_SHORT).show()
            } else {
                val (entry, risk, hash) = result
                openDetail(entry, risk, hash)
            }
        }
    }

    private fun openDetail(entry: AppEntry, risk: RiskResult, hash: String?) {
        val intent = Intent(this, ApkDetailActivity::class.java).apply {
            putExtra("label", entry.label)
            putExtra("packageName", entry.packageName)
            putExtra("versionName", entry.versionName ?: "-")
            putStringArrayListExtra("permissions", ArrayList(entry.permissions))
            putExtra("score", risk.score)
            putExtra("level", risk.level)
            putExtra("hash", hash)
            putExtra("lang", Lang.current.name)
        }
        startActivity(intent)
    }
}
