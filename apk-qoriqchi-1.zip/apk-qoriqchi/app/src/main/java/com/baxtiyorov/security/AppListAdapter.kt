package com.baxtiyorov.security

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppListAdapter(
    private val items: List<Pair<AppEntry, RiskResult>>,
    private val onClick: (AppEntry, RiskResult) -> Unit
) : RecyclerView.Adapter<AppListAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val label: TextView = view.findViewById(R.id.appLabel)
        val pkg: TextView = view.findViewById(R.id.appPackage)
        val score: TextView = view.findViewById(R.id.riskScoreText)
        val dot: View = view.findViewById(R.id.riskDot)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val (entry, risk) = items[position]
        holder.label.text = entry.label
        holder.pkg.text = entry.packageName
        holder.score.text = risk.score.toString()

        val color = when (risk.level) {
            "high" -> Color.parseColor("#C62828")
            "medium" -> Color.parseColor("#F9A825")
            else -> Color.parseColor("#2E7D32")
        }
        holder.score.setTextColor(color)
        (holder.dot.background as? GradientDrawable)?.setColor(color)
            ?: run { holder.dot.setBackgroundColor(color) }

        holder.itemView.setOnClickListener { onClick(entry, risk) }
    }

    override fun getItemCount() = items.size
}
