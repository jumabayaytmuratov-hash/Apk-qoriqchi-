package com.baxtiyorov.security

import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ApkDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apk_detail)

        Lang.current = try {
            AppLang.valueOf(intent.getStringExtra("lang") ?: "KAA")
        } catch (e: Exception) {
            AppLang.KAA
        }

        val label = intent.getStringExtra("label") ?: "-"
        val pkg = intent.getStringExtra("packageName") ?: "-"
        val version = intent.getStringExtra("versionName") ?: "-"
        val permissions = intent.getStringArrayListExtra("permissions") ?: arrayListOf()
        val score = intent.getIntExtra("score", 0)
        val level = intent.getStringExtra("level") ?: "low"
        val hash = intent.getStringExtra("hash")

        findViewById<TextView>(R.id.detailLabel).text = label
        findViewById<TextView>(R.id.detailPackage).text = "$pkg  •  ${Lang.t("version")}: $version"

        val riskColor = when (level) {
            "high" -> Color.parseColor("#C62828")
            "medium" -> Color.parseColor("#F9A825")
            else -> Color.parseColor("#2E7D32")
        }
        val riskLabelKey = when (level) {
            "high" -> "risk_high"
            "medium" -> "risk_medium"
            else -> "risk_low"
        }

        val riskLevelText = findViewById<TextView>(R.id.riskLevelText)
        riskLevelText.text = Lang.t(riskLabelKey)
        riskLevelText.setTextColor(riskColor)

        findViewById<TextView>(R.id.riskScoreDetailText).text = "${Lang.t("risk_score")}: $score / 100"

        val hashLabel = findViewById<TextView>(R.id.hashLabel)
        val hashValue = findViewById<TextView>(R.id.hashValue)
        if (hash != null) {
            hashLabel.text = Lang.t("sha256_hash")
            hashValue.text = hash
        } else {
            hashLabel.visibility = android.view.View.GONE
            hashValue.visibility = android.view.View.GONE
        }

        findViewById<TextView>(R.id.permissionsLabel).text = Lang.t("permissions")
        val container = findViewById<LinearLayout>(R.id.permissionsContainer)

        // Dangerous permissions get highlighted; the rest are shown plainly.
        val weightedNames = RiskAnalyzer.dangerousPermissionSet()

        if (permissions.isEmpty()) {
            addPermissionRow(container, Lang.t("no_dangerous_permissions"), false)
        } else {
            permissions.sortedByDescending { weightedNames.contains(it) }.forEach { perm ->
                addPermissionRow(container, perm.removePrefix("android.permission."), weightedNames.contains(perm))
            }
        }
    }

    private fun addPermissionRow(container: LinearLayout, text: String, dangerous: Boolean) {
        val tv = TextView(this)
        tv.text = if (dangerous) "⚠ $text" else "• $text"
        tv.textSize = 13f
        tv.setTextColor(if (dangerous) Color.parseColor("#C62828") else Color.parseColor("#5F6673"))
        tv.setPadding(0, 6, 0, 6)
        container.addView(tv)
    }
}
